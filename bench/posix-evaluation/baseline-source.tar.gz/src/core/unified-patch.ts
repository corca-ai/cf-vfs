import { VfsError } from "./errors.js";
import { splitLinesPreservingEndings } from "./lines.js";

type PatchLineKind = "context" | "delete" | "insert";

interface PatchLine {
  kind: PatchLineKind;
  text: string;
}

interface PatchHunk {
  oldStart: number;
  oldCount: number;
  newStart: number;
  newCount: number;
  lines: PatchLine[];
}

export interface ApplyUnifiedPatchResult {
  text: string;
  hunks: number;
  additions: number;
  deletions: number;
}

function patchLines(patch: string): string[] {
  if (patch.length === 0) return [];
  const lines = splitLinesPreservingEndings(patch);
  if (!patch.endsWith("\n")) {
    throw new VfsError("EINVAL", "patch must end with a newline");
  }
  return lines;
}

function decimalValue(value: string | undefined, fallback?: number): number {
  if (value === undefined && fallback !== undefined) return fallback;
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed < 0) {
    throw new VfsError("EINVAL", "patch hunk line numbers must be safe non-negative integers");
  }
  return parsed;
}

function patchLineKind(prefix: string | undefined, lineNumber: number): PatchLineKind {
  if (prefix === " ") return "context";
  if (prefix === "-") return "delete";
  if (prefix === "+") return "insert";
  throw new VfsError("EINVAL", `invalid patch line at line ${lineNumber}`);
}

function consumeHunkLines(lines: readonly string[], start: number, hunk: PatchHunk): number {
  let index = start;
  while (index < lines.length && !lines[index]?.startsWith("@@ ")) {
    const line = lines[index];
    if (line === undefined) break;
    if (line === "\\ No newline at end of file\n") {
      const previous = hunk.lines.at(-1);
      if (!previous?.text.endsWith("\n")) {
        throw new VfsError("EINVAL", `misplaced no-newline marker at line ${index + 1}`);
      }
      previous.text = previous.text.slice(0, -1);
    } else {
      hunk.lines.push({ kind: patchLineKind(line[0], index + 1), text: line.slice(1) });
    }
    index += 1;
  }
  return index;
}

function validateHunkCounts(hunk: PatchHunk): void {
  const oldCount = hunk.lines.filter((line) => line.kind !== "insert").length;
  const newCount = hunk.lines.filter((line) => line.kind !== "delete").length;
  if (oldCount !== hunk.oldCount || newCount !== hunk.newCount) {
    throw new VfsError("EINVAL", "patch hunk line counts do not match its header");
  }
}

function parseHunks(patch: string): PatchHunk[] {
  const lines = patchLines(patch);
  if (!lines[0]?.startsWith("--- ") || !lines[1]?.startsWith("+++ ")) {
    throw new VfsError("EINVAL", "patch must start with --- and +++ headers");
  }

  const hunks: PatchHunk[] = [];
  let index = 2;
  while (index < lines.length) {
    const header = lines[index];
    const match = header?.match(/^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?:[^\n]*)\n$/u);
    if (!match) throw new VfsError("EINVAL", `invalid patch hunk header at line ${index + 1}`);
    const hunk: PatchHunk = {
      oldStart: decimalValue(match[1]),
      oldCount: decimalValue(match[2], 1),
      newStart: decimalValue(match[3]),
      newCount: decimalValue(match[4], 1),
      lines: [],
    };
    index += 1;
    index = consumeHunkLines(lines, index, hunk);
    validateHunkCounts(hunk);
    hunks.push(hunk);
  }
  if (hunks.length === 0) throw new VfsError("EINVAL", "patch contains no hunks");
  return hunks;
}

function hunkIndex(start: number, count: number): number {
  if (count === 0) return start;
  if (start < 1) throw new VfsError("EINVAL", "patch hunk line numbers are invalid");
  return start - 1;
}

function applyHunk(
  source: readonly string[],
  hunk: PatchHunk,
  sourceIndex: number,
  output: string[],
): { readonly sourceIndex: number; readonly additions: number; readonly deletions: number } {
  const start = hunkIndex(hunk.oldStart, hunk.oldCount);
  if (start < sourceIndex || start > source.length) {
    throw new VfsError("EINVAL", "patch hunks are overlapping or outside the file");
  }
  for (let index = sourceIndex; index < start; index += 1) output.push(source[index] ?? "");
  let nextSource = start;
  if (hunkIndex(hunk.newStart, hunk.newCount) !== output.length) {
    throw new VfsError("EINVAL", "patch hunk new-file position is inconsistent");
  }
  let additions = 0;
  let deletions = 0;
  for (const line of hunk.lines) {
    if (line.kind === "insert") {
      output.push(line.text);
      additions += 1;
      continue;
    }
    if (source[nextSource] !== line.text) {
      throw new VfsError("EREVISION", "patch context does not match the current file");
    }
    if (line.kind === "context") output.push(line.text);
    else deletions += 1;
    nextSource += 1;
  }
  return { sourceIndex: nextSource, additions, deletions };
}

export function applyUnifiedPatch(source: string, patch: string): ApplyUnifiedPatchResult {
  const sourceContent = splitLinesPreservingEndings(source);
  const output: string[] = [];
  const hunks = parseHunks(patch);
  let sourceIndex = 0;
  let additions = 0;
  let deletions = 0;

  for (const hunk of hunks) {
    const applied = applyHunk(sourceContent, hunk, sourceIndex, output);
    sourceIndex = applied.sourceIndex;
    additions += applied.additions;
    deletions += applied.deletions;
  }
  for (let index = sourceIndex; index < sourceContent.length; index += 1)
    output.push(sourceContent[index] ?? "");
  return { text: output.join(""), hunks: hunks.length, additions, deletions };
}
